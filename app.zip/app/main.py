from flask import Flask, render_template, request
import mysql.connector


app = Flask('Resturant Management')

@app.route('/')
def home():


    return render_template('login.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    username = str(request.form.get('uname'))
    password = str(request.form.get('psw'))
    mycursor = mydb.cursor()
    sql = "SELECT * FROM user_details where username = %s and password = %s"
    adr = (username, password)
    mycursor.execute(sql, adr)
    myresult = mycursor.fetchall()
    if(len(myresult)>0):
        #return render_template('group.html')
        mycursor = mydb.cursor()
        mycursor.execute("SELECT * FROM restaurant")

        myresult = mycursor.fetchall()
        restaurant_list = []
        for x in myresult:
            restaurant_list.append(x[0])
        return render_template('home.html',restaurant_list=restaurant_list)
    else:
        return render_template('loginError.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    username = str(request.form.get('email'))
    password = str(request.form.get('psw'))
    mycursor = mydb.cursor()
    sql = """INSERT INTO user_details(username,password) VALUES (%s,%s)"""
    args =(username,password)
    mycursor.execute(sql,args)
    mydb.commit()

    return render_template('login.html')

@app.route('/table_full', methods=['GET', 'POST'])
def table_full():
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM restaurant")

    myresult = mycursor.fetchall()
    restaurant_list = []
    for x in myresult:
        restaurant_list.append(x[0])
    return render_template('home.html',restaurant_list=restaurant_list)


@app.route('/book-table', methods=['GET', 'POST'])
def restaurant_selection():

    mycursor = mydb.cursor()
    global restaurant_name
    restaurant_name = str(request.form.get('restaurant_list'))
    mycursor = mydb.cursor()
    sql = "SELECT * FROM restaurant_table where name = %s and status = False"
    args =(restaurant_name,)
    mycursor.execute(sql,args)

    myresult = mycursor.fetchall()
    menu_book = ['Yes','No']
    if(len(myresult)>0):
        mycursor = mydb.cursor()
        sql = "UPDATE restaurant_table SET status = True WHERE name = %s and tableno = %s"
        adr = (restaurant_name, myresult[0][1])
        mycursor.execute(sql, adr)
        mydb.commit()        
        return render_template('book_confirm.html',restaurant_name = restaurant_name, menu_book=menu_book,table_number = myresult[0][1])
    else:
        return render_template('table_full.html')

@app.route('/menu-book', methods=['GET', 'POST'])
def menu_book():
    
    menu_book = str(request.form.get('menu_book'))
    mycursor = mydb.cursor()
    sql = "select * from menu_details"

    mycursor.execute(sql)

    myresult = mycursor.fetchall()
    menu_item = []
    price = []
    for x in myresult:
        menu_item.append(x[0])
        price.append(x[1])
    if(menu_book == 'Yes'):
        return render_template('menu_select.html',type=type,reqIDs_msgs_rcs=zip(menu_item ,price))
    else:
        return render_template('final.html')

@app.route('/menu-confirm', methods=['GET', 'POST'])
def menu_confirm():
    
    menu_book = request.form.getlist('menu')
    mycursor = mydb.cursor()
    sql = "select * from menu_details"

    mycursor.execute(sql)

    myresult = mycursor.fetchall()
    price_calculate=[]
    for x in myresult:
        if(x[0] in menu_book):
            price_calculate.append(x[1])
    total_sum = sum(price_calculate)
    return render_template('menu_summary.html',total_sum = total_sum)
    
if __name__ == '__main__':
    mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="admin",
  database="mydatabase"
)
    app.run(host = "0.0.0.0",use_reloader=False)
